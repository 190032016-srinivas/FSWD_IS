export const Header = () => {
  return (
    <div
      style={{
        fontFamily: "monospace",
        fontSize: "40px",
        // border: "2px solid red",
        width: "max-content",
        marginTop: "10px",
      }}
    >
      My To Do List
    </div>
  );
};
