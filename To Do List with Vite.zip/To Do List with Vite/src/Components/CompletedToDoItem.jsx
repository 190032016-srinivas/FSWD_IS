export const CompletedTodoListItem = ({ toDo }) => {
  return <div id="completed_todo_item">{"> " + toDo}</div>;
};
