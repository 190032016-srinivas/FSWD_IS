- github link https://github.com/190032016-srinivas/To-Do-List-with-Vite

* this is a basic to do application
* all components are in a components folder
* all the dependencies are in the package.json

- DONT FORGET TO RUN \*\* NPM INSTALL
- DONT FORGET TO RUN \*\* NPM INSTALL

* we need mui library for react and uuid for unique id generation
* that is it try it out and have a nice day

- thank you
